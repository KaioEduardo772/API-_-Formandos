package com.alunos.formandos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormandosApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormandosApplication.class, args);
	}

}
